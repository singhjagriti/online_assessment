        <?php include "includes/header.php"; ?>
   
     <nav class="navbar navbar-inverse navbar-fixed-top navb1" role="navigation" id="top">
            <div class="container">
            <!-- for mobile devices-->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" style="color: black;">Online Assessment</a>
                </div>
                
            <!--navigations -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav navbar-right side-nav">
                        <li class="active"><a href="users/user_index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
                        <li class="dropdown">
                        <a href="#" class="dropdown-toggle text" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['f_name']." ".$_SESSION['s_name'];?><b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="#"><i class="fa fa-fw fa-user"></i><?php echo $_SESSION['email']; ?></a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>