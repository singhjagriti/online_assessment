<?php include "../includes/db.php";?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Online Assessment Portal</title>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="It is a website to assess the skills of the individual.">
        <meta name="author" content="">
        <!-- this is core bootstrap css -->
        <link type="text/css" rel="stylesheet" href="../css/bootstrap.min.css">
        <!-- Fontawesome -->
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <!-- custom css -->
        <link rel="stylesheet" href="../css/blog_home.css" type="text/css">
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
        <style>
            .grid{
                border: 1px solid gray;
                box-shadow: lightgray 5px 5px;
                padding: 10px;
                margin: 30px;
                border-radius: 10px;
                height: 350px;
            }
            .form1{
                border: 2px solid black;
                padding: 2% 5% 5% 5%;
                margin: 0 10% 5% 10%;
                border-radius: 10px;
                background: lightgray;
                
            }
            .center 
            {
                width: 100px;
                height: 100px;
                display: block;
                margin-right: auto;
                margin-left: auto;
                margin-bottom: 30px;
                border-radius: 50%;
            }
            .button1
            {
                margin: 0 15px 0 15px;
            }
        </style>
        <script type="text/javascript">
        function timeout()
        {
            var minute = Math.floor(timeLeft/60);
            var second = timeLeft%60;
            var mint = timestamp(minute);
            var sec = timestamp(second);
            if(timeLeft<=0)
            {
                clearTimeout(tm);
                document.getElementById("form1").submit();
            }
            else{
                document.getElementById("time").innerHTML = mint + ":" +sec;
            }
            timeLeft--;
            var tm = setTimeout(function(){timeout()},1000);
        }
        function timestamp(msg)
        {
            if(msg<10)
            {
                msg = "0"+msg;
            }
            return msg;
        }

        </script>
    </head>
    <body onload="timeout()">
        <!--This is the page content-->
            <div class="container">
            <p style="color: red;">NOTE: Do not refresh the page and don't use keyboard.</p>
            <h2 style="color: white;">Data Structure 
            <script type="text/javascript">
               var timeLeft = 5*60;
            </script>
            <div style="float:right; color: white;" id="time"></div></h2>
                <div class="row">
                <!-- Main page content-->
                <div class="col-lg-12 well">
            <form action="ds_answer.php" method="post" id="form1">
                    <?php
                          $i = 1;
                          $query = "SELECT * FROM ds_quiz";
                          $select_questions = mysqli_query($connection, $query);
                        
                          while($row = mysqli_fetch_assoc($select_questions))
                          {
                            $question = $row['question'];
                            $option1 = $row['option1'];
                            $option2 = $row['option2'];
                            $option3 = $row['option3'];
                            $option4 = $row['option4'];
                            $ques_no = $row['ques_no'];
                            $correct_answer = $row['correct_answer'];

                              ?>

                        <table class="table table-bordered table-header">
                            <thead>
                                <tr class="danger">
                                    <th><?php echo $i; ?>:&emsp;<?php echo $question; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($option1)){?>
                                <tr class="info">
                                    <td>&nbsp;1&emsp;<input type="radio" value="1" name="<?php echo $ques_no; ?>">&nbsp; <?php echo $option1; ?></td>
                                </tr>
                            <?php } ?>
                            <?php if(isset($option2)){?>
                                <tr class="info">
                                    <td>&nbsp;2&emsp;<input type="radio" value="2" name="<?php echo $ques_no; ?>">&nbsp; <?php echo $option2; ?></td>
                                </tr>
                                <?php } ?>
                                <?php if(isset($option3)){?>
                                <tr class="info">
                                    <td>&nbsp;3&emsp;<input type="radio" value="3" name="<?php echo $ques_no; ?>">&nbsp; <?php echo $option3; ?></td>
                                </tr>
                                <?php } ?>
                                <?php if(isset($option4)){?>
                                <tr class="info">
                                    <td>&nbsp;4&emsp;<input type="radio" value="4" name="<?php echo $ques_no; ?>">&nbsp; <?php echo $option4; ?></td>
                                </tr>
                                <?php } ?>
                                <tr class="info">
                                    <td><input type="radio" checked="checked" style="display: none;" value="not_answer" name="<?php echo $ques_no; ?>"></td>
                                </tr>

                            </tbody>
                        </table>
                          <?php $i++; } ?>
                        <button type="submit" name="result" class="btn btn-success">Submit</button>

                        </form>
                    </div>

                </div>
            </div>
</body>
    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <!-- javascript file-->
    <script src="../js/bootstrap.min.js">
    </script>

</html>