<?php

        if(isset($_GET['p_Id'])){
            $the_ques_no = $_GET['p_Id'];

        }

        $query = "SELECT * FROM posts";
        $select_posts_by_id = mysqli_query($connection, $query);             
        while($row = mysqli_fetch_assoc($select_posts_by_id))
        {
            $post_author = $row['post_author'];
            $post_title = $row['post_title'];
            $post_category_id = $row['post_category_id'];
            $post_status = $row['post_status'];
            $post_image = $row['post_image'];
            $post_tag = $row['post_tag'];
            $post_content = $row['post_content'];
        }

            if(isset($_POST['add_post_to_db'])){
            $post_author =  $_POST['post_author'];
            $post_title =  $_POST['post_title'];
            $post_category_id =  $_POST['post_category'];
            $post_status =  $_POST['post_status'];
            $post_tag =  $_POST['post_tag'];
            $post_image =  $_FILES['post_image'];
            $post_image_temp =  $_FILES['post_image_temp'];
            $post_content =  $_POST['post_content'];

            move_uploaded_file($post_image_temp, "../images/$post_image");







        }
?>




<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title">Post Title</label>
        <input value="<?php echo $post_title;?>" type="text" class="form-control" name="post_title">
    </div>
    <div class="form-group">
        <select name="post_category" id="">
        <?php
        $query = "SELECT * FROM categories";
        $select_categories = mysqli_query($connection, $query);
        confirm_query($select_categories);
      
        while($row = mysqli_fetch_assoc($select_categories))
        {
            $cat_id = $row['cat_id'];
            $cat_title = $row['cat_title'];
            echo "<option value='$cat_id'>{$cat_title}</option>";
        }
        
        ?>
        
        
        </select>
    </div>
    <div class="form-group">
        <label for="author">Author</label>
        <input value="<?php echo $post_author; ?>" type="text" class="form-control" name="post_author">
    </div>
    <div class="form-group">
        <label for="post_status">Status</label>
        <input value="<?php echo $post_status; ?>" type="text" class="form-control" name="post_status">
    </div>
    <div class="form-group">
        <img width="100" src="../images/<?php echo $post_image;?>" alt="<?php echo $_GET['p_Id'];?>">
    </div>
    <div class="form-group">
        <label for="post_tag">Tags</label>
        <input value="<?php echo $post_tag; ?>" type="text" class="form-control" name="post_tag">
    </div>
    <div class="form-group">
        <label for="post_content">Content</label>
        <textarea class="form-control" name="post_content" cols="30" row="10">
        <?php echo $post_content; ?>
        </textarea>
    </div>
    <div class="form-group"></div>
        <input type="submit" class="btn btn-primary" name="add_post_to_db" value="Publish Post">
    </div>

</form>