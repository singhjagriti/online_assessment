
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome
                            <small>Admin!!!</small>
                        </h1>
                        <center>
                        <h2>Admin Bio</h2>
                        <hr width= 200;>
                        <h3>ANKUR RATHI</h3>
                        <h4>Student of Institute of Engineering and Technology </h4>
                        <h5>MCA 2nd year 4th semester</h5>
                        <h5>Roll No. 1705214004</h5>
                        <h5>Semester MINI PROJECT</h5>
                       <center>
                    </div>
                </div>
                <!-- /.row -->

            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
