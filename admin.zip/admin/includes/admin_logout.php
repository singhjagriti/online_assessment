<?php session_start();?>

<?php 
$_SESSION['username']=NULL;
$_SESSION['password']=NULL;
session_unset();

header("Location: ../../index.php");

?>