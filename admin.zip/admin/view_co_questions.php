<?php include "includes/admin_header.php" ?>

<div id="wrapper">

<?php include "includes/admin_navigation.php" ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">

                <div class="col-lg-12">

                <h1 class="page-header">
                        Computer organisation
                        <small>Questions</small>
                </h1>
                      
                    <table class="table table-bordered table-header">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Question</th>
                                <th>option1</th>
                                <th>option2</th>
                                <th>option3</th>
                                <th>option4</th>
                                <th>correct Answer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM co_quiz";
                            $select_questions = mysqli_query($connection, $query);
                          
                            while($row = mysqli_fetch_assoc($select_questions))
                            {
                                $ques_no = $row['ques_no'];
                                $question = $row['question'];
                                $option1 = $row['option1'];
                                $option2 = $row['option2'];
                                $option3 = $row['option3'];
                                $option4 = $row['option4'];
                                $correct_answer = $row['correct_answer'];


                                echo "<tr>";
                                echo "<td>{$ques_no}</td>";
                                echo "<td>{$question}</td>";
                                echo "<td>{$option1}</td>";
                                echo "<td>{$option2}</td>";
                                echo "<td>{$option3}</td>";
                                echo "<td>{$option4}</td>";
                                echo "<td>{$correct_answer}</td>";
                               
                                echo "<td><a href='co_quiz.php?delete={$ques_no}'>Delete</td>";
                                echo "<td><a href='co_quiz.php?p_Id={$ques_no}'>Edit</td>";
                                echo "</tr>";
                            }
                            ?>
                            <?php 
                            if(isset($_GET['delete']))
                            {
                            $the_ques_no = $_GET['delete'];
                            $query = "DELETE FROM co_quiz WHERE ques_no = {$the_ques_no}";
                            $delete = mysqli_query($connection, $query);
                            header('Location: c_quiz.php');
                            }

                            ?>
                        </tbody>
                    </table>
  
                </div>

            </div> <!--end of page heading-->

        </div> <!-- end of container fluid-->

    </div><!-- end of page rapper-->

<?php include "includes/admin_footer.php" ?>
