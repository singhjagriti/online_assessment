<?php include "includes/admin_header.php" ?>

<div id="wrapper">

<?php include "includes/admin_navigation.php" ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">

                <div class="col-lg-12">

                <h1 class="page-header">
                        All Users Info
                </h1>
                      
                    <table class="table table-bordered table-header">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM register";
                            $select_questions = mysqli_query($connection, $query);
                            $i=1;
                            while($row = mysqli_fetch_assoc($select_questions))
                            {
                                $f_name = $row['f_name'];
                                $s_name = $row['s_name'];
                                $email = $row['email'];
                                $m_number = $row['m_number'];

                                echo "<tr>";
                                echo "<td>{$i}</td>";
                                echo "<td>{$f_name} {$s_name}</td>";
                                echo "<td>{$email}</td>";
                                echo "<td>{$m_number}</td>";
                            
                                echo "</tr>";
                                $i++;
                            }
                            
                            
                            ?>



                        </tbody>
                    </table>
  
                </div>

            </div> <!--end of page heading-->

        </div> <!-- end of container fluid-->

    </div><!-- end of page rapper-->

<?php include "includes/admin_footer.php" ?>
