<?php session_start();?>
<?php 
      $_SESSION['email']=NULL;
      $_SESSION['password1']=NULL;
      $_SESSION['f_name']=NULL;
      $_SESSION['s_name']=NULL;
      session_unset();

      header("Location: ../index.php")

?>