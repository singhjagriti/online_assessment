<footer class="page-footer">
     <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <p class="footer">Copyright &copy; 2019 by <a href="">Anukriti</a></p>
                </div>
            </div>
     </div>
</footer>


    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- javascript file-->
    <script src="js/bootstrap.min.js">
    </script>
 </body>
</html>