<div class="col-md-4 one">
                        <div class="well">
                        <h4>Tests</h4>
                           <ul>
                           <li><a href="user_C_prog.php">C-programming</a></li>
                           <li><a href="user_ds.php">Data Structure</a></li>
                           <li><a href="user_automata.php">Automata</a></li>
                           <li><a href="user_daa.php">Design and Analysis of Algorithm</a></li>
                           <li><a href="user_os.php">Operating System</a></li>
                           <li><a href="user_dbms.php">Database Management System</a></li>
                           <li><a href="user_cd.php">Compiler Design</a></li>
                           <li><a href="user_co.php">Computer Organisation</a></li>
                           <li><a href="user_python.php">Python</a></li>

                           </ul>
                        </div>
                        <div class="well">
                        <h3>About!</h3>
                        <hr>
                           <p>Assessment can be focused on the individual learner or all individuals together, like the whole class, an institution or specific program. Formative assessment will give you an overview of your students in the beginning of your instruction.
                           A major highlight of using an online examination system is that it gives a high level of transparency as opposed to the traditional method. Most online exams generate their results instantly and it is often possible for the exam taker to get information on his results immediately.</p>
                        </div>


                    </div>